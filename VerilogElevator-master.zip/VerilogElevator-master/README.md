# <center>Elevator-Simulation with MIPS Assembly</center>
## <center>on MIPS32 CPU with Verilog HDL</center>
#### Author: Liutianchen<br>Department of Computer Science, College of Electronic and Information Engineering, Tongji University

## MIPS流程图

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image1.png)

## VGA/键盘 I/O接口

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image3.png)

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image5.png)

## 功能说明

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image8.png)

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image10.png)

## 下板演示

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image7.jpeg)

![](https://github.com/Liutianchen/VerilogElevator/raw/master/readme_img/image9.jpeg)


## 创新与改进

* 图形界面
* 增加了键盘操作逻辑
* 修正了最远换向逻辑
* 增加倒计时条

## 难点

* 键盘时钟，CPU时序部件时钟，VGA时钟同步
	* <font color=red>将VGA时钟和CPU时钟同时降频延长时钟差</font>
* RAM监视位的电梯扫描和CPU并行执行
	* <font color=red>使用Verilog并行写入</font>
* 显示比较复杂的形状和色彩
	* <font color=red>使用Matlab处理图像矩阵后导入IP核</font>

