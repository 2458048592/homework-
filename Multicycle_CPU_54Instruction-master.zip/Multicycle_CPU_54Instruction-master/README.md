# Multicycle_CPU_54Instruction
## A Simple Multicycle CPU With 54 MIPS Instructions
## 简单的MIPS指令集多周期CPU
The aim of the project is to learn something about architecture of CPU and computer. Documents and test data will not be uploaded as this is also a assignment in a university.

该项目旨在学习计算机组成原理和CPU结构。文档和测试数据将不会被公开。学弟学妹们可以参考代码，在此基础上做出更加复杂和精细的CPU。

 - Written by Verilog
 - With 54 MIPS instructions
 - Without cache
 - Run successfully in vivado 2016
 - Errors in vivado 2017 
 - Author know little about Verilog but finish this project still, this is a terrible example of Verilog
 - Working against the clock to finish this assignment, which makes the code a mess