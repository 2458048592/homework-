//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ResFIR.rc
//
#define IDD_DIALOG1                     101
#define IDB_BOARD                       102
#define IDR_MENU                        104
#define IDD_NEWG                        108
#define IDI_ICONF                       109
#define IDR_PUT                         114
#define IDD_ABOUT                       127
#define IDD_ABOUTBOX                    127
#define IDC_CHOOSEB                     1005
#define IDC_CHOOSEW                     1006
#define IDC_DIFE                        1020
#define IDC_DIFN                        1021
#define IDC_DIFD                        1022
#define IDC_DIFM                        1023
#define IDC_DIFF                        1024
#define IDC_MINMAX                      1026
#define IDC_ALPHABETA                   1027
#define ID_40001                        40001
#define ID_40002                        40002
#define ID_40003                        40003
#define IDM_EXIT                        40005
#define IDM_NEWG                        40006
#define ID_40007                        40007
#define ID_40008                        40008
#define IDM_ABOUT                       40009
#define IDM_RETRACT                     40010
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
